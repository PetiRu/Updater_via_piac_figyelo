import yfinance as yf
import pandas as pd
import datetime
import os

LOG_FILE = "error.log"

def write_log(message: str):
    """Hozzáfűzi az üzenetet az error.log fájlhoz időbélyeggel, létrehozza, ha nincs"""
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            f.write(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Log fájl létrehozva\n")
    
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"[{timestamp}] {message}\n")

def calc_stochastic_d(data, length=14, k_smooth=4, d_smooth=3):
    """Számolja a Stochastic %D-et pandas DataFrame alapján"""
    lowest_low = data['Low'].rolling(window=length).min()
    highest_high = data['High'].rolling(window=length).max()
    raw_k = 100 * (data['Close'] - lowest_low) / (highest_high - lowest_low)
    k_sma = raw_k.rolling(k_smooth).mean()
    d_sma = k_sma.rolling(d_smooth).mean()
    return d_sma

def check_stochastic_buy(name, ticker):
    """
    Ellenőrzi a Stochastic %D jelzést:
    - 1 napos TF
    - 16-os vonal alulról történő átlépése → TALÁLAT
    Visszatér: (érték, crossed_today) vagy None
    """
    try:
        df = yf.download(ticker, period="6mo", interval="1d", progress=False, auto_adjust=True)
        if df.empty:
            write_log(f"Nincs adat: {name} ({ticker})")
            return None

        df['%D'] = calc_stochastic_d(df)
        last_d = df['%D'].iloc[-1]
        prev_d = df['%D'].iloc[-2]

        crossed_today = prev_d < 16 <= last_d  # alulról történt átlépés
        return (round(last_d, 2), crossed_today)

    except Exception as e:
        write_log(f"Hiba letöltés közben: {name} ({ticker}) - {e}")
        return None

