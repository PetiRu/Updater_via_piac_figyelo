import requests
import json
import os

# ---------------- Konfiguráció -----------------
BASE_URL = "https://raw.githubusercontent.com/PetiRu/Updater_via_piac_figyelo/main/Krisz/"
VERSION_PATH = "version.json"  # a main mappában van
LOCAL_VERSION_FILE = "local_version.json"

# ---------------- Verzió fájl kezelése -----------------
def ensure_local_version_file():
    """Létrehozza a local_version.json fájlt, ha nem létezik"""
    if not os.path.exists(LOCAL_VERSION_FILE):
        with open(LOCAL_VERSION_FILE, "w", encoding="utf-8") as f:
            json.dump({"version": "0.0"}, f, indent=4)
        print("[INFO] local_version.json létrehozva alapértelmezett verzióval 0.0")

def fetch_version():
    """Lekéri a version.json-t a GitHub-ról"""
    url = BASE_URL + VERSION_PATH
    try:
        r = requests.get(url)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print("[ERROR] Nem sikerült lekérni a verziót:", e)
        return None

def save_local_version(version):
    """Mentés a helyi JSON-ba"""
    ensure_local_version_file()
    with open(LOCAL_VERSION_FILE, "w", encoding="utf-8") as f:
        json.dump({"version": version}, f, indent=4)
    print(f"[INFO] Helyi verzió elmentve: {version}")

def get_local_version():
    """Visszaadja a helyi verziót"""
    ensure_local_version_file()
    with open(LOCAL_VERSION_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get("version", "0.0")

# ---------------- Fájl frissítés -----------------
def update_file(filename):
    """Egy fájl frissítése a GitHub-ról"""
    url = BASE_URL + filename
    try:
        r = requests.get(url)
        r.raise_for_status()
        with open(filename, "w", encoding="utf-8") as f:
            f.write(r.text)
        print(f"[INFO] {filename} sikeresen frissítve!")
        return True
    except Exception as e:
        print(f"[ERROR] Hiba a {filename} frissítésekor:", e)
        return False

def update_all():
    """Frissíti az összes fájlt a version.json alapján és menti a verziót"""
    ensure_local_version_file()

    version_data = fetch_version()
    if not version_data:
        return {}

    version = version_data.get("version", "0.0")
    files_to_update = version_data.get("files", [])

    results = {}
    for f in files_to_update:
        results[f] = update_file(f)

    save_local_version(version)
    return results

