import yfinance as yf
import pandas as pd
import datetime
import os

LOG_FILE = "error.log"

def write_log(message: str):
    """Hozzáfűzi az üzenetet az error.log fájlhoz időbélyeggel, létrehozza, ha nincs"""
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            f.write(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Log fájl létrehozva\n")
    
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"[{timestamp}] {message}\n")

def calc_stochastic(data, period=14):
    """Stochastic Oscillator (%K) számítása pandas DataFrame alapján"""
    low_min = data['Low'].rolling(window=period).min()
    high_max = data['High'].rolling(window=period).max()
    stoch_k = 100 * (data['Close'] - low_min) / (high_max - low_min)
    return stoch_k

def check_stochastic(name, ticker):
    """Lekéri az adatokat a yfinance-ról és megnézi a Stochastic értéket"""
    try:
        df = yf.download(ticker, period="6mo", interval="1d", progress=False)
        if df.empty:
            write_log(f"Nincs adat: {name} ({ticker})")
            return None
        df['%K'] = calc_stochastic(df)
        last_k = df['%K'].iloc[-1]
        return round(last_k, 2)
    except Exception as e:
        write_log(f"Hiba letöltés közben: {name} ({ticker}) - {e}")
        return None

