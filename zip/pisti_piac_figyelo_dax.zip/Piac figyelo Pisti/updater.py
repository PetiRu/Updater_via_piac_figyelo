import requests
import json
import os

# ---------------- Konfiguráció -----------------
BASE_URL = "https://raw.githubusercontent.com/PetiRu/Updater_via_piac_figyelo/main/Pisti/"
VERSION_PATH = "version.json"
LOCAL_VERSION_FILE = "local_version.json"

# ---------------- Verzió fájl kezelése -----------------
def ensure_local_version_file():
    if not os.path.exists(LOCAL_VERSION_FILE):
        with open(LOCAL_VERSION_FILE, "w", encoding="utf-8") as f:
            json.dump({"version": "0.0"}, f, indent=4)
        print("[INFO] local_version.json létrehozva alapértelmezett verzióval 0.0")

def get_local_version():
    ensure_local_version_file()
    with open(LOCAL_VERSION_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get("version", "0.0")

def save_local_version(version):
    with open(LOCAL_VERSION_FILE, "w", encoding="utf-8") as f:
        json.dump({"version": version}, f, indent=4)
    print(f"[INFO] Helyi verzió elmentve: {version}")

# ---------------- GitHub verzió lekérése -----------------
def fetch_version():
    url = BASE_URL + VERSION_PATH
    try:
        r = requests.get(url)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print("[ERROR] Nem sikerült lekérni a verziót:", e)
        return None

# ---------------- Fájl frissítés -----------------
def update_file(filename):
    url = BASE_URL + filename
    try:
        r = requests.get(url)
        r.raise_for_status()
        with open(filename + ".tmp", "w", encoding="utf-8") as f:
            f.write(r.text)
        os.replace(filename + ".tmp", filename)
        print(f"[INFO] {filename} sikeresen frissítve!")
        return True
    except Exception as e:
        print(f"[ERROR] Hiba a {filename} frissítésekor:", e)
        return False

def update_all():
    """Csak akkor frissít, ha a GitHub verzió újabb"""
    local_ver = get_local_version()
    version_data = fetch_version()
    if not version_data:
        return

    remote_ver = version_data.get("version", "0.0")
    if remote_ver <= local_ver:
        print(f"[INFO] Nincs új verzió. Helyi: {local_ver}, GitHub: {remote_ver}")
        return

    print(f"[INFO] Új verzió elérhető! Helyi: {local_ver}, GitHub: {remote_ver}")
    files_to_update = version_data.get("files", [])

    for f in files_to_update:
        update_file(f)

    save_local_version(remote_ver)
    print("[INFO] Frissítés kész!")

# ---------------- Futtatás -----------------
if __name__ == "__main__":
    ensure_local_version_file()
    update_all()

