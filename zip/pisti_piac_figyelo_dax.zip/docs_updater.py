import requests
import os
import json
from pathlib import Path
import shutil

# GitHub alap URL
BASE_URL = "https://raw.githubusercontent.com/PetiRu/Updater_via_piac_figyelo/main/"
# Desktop Dokumentacio mappa
DESKTOP = Path.home() / "Desktop"
DOCS_BASE_DIR = DESKTOP / "Dokumentacio"

def fetch_version():
    """Lekéri a version.json-t a GitHub-ról"""
    url = BASE_URL + "version/version.json"
    try:
        r = requests.get(url)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print("[ERROR] Nem sikerült lekérni a verziót:", e)
        return None

def clear_old_versions(new_version):
    """Törli az összes régi verzió mappát, csak az új marad"""
    if DOCS_BASE_DIR.exists():
        for item in DOCS_BASE_DIR.iterdir():
            if item.is_dir() and item.name != f"v{new_version}":
                try:
                    shutil.rmtree(item)
                    print(f"[INFO] Régi verzió törölve: {item.name}")
                except Exception as e:
                    print(f"[ERROR] Nem sikerült törölni a régi verziót {item.name}: {e}")

def download_pdf(file_path, version):
    """Letölti a PDF-et és a Desktop Dokumentacio/<verzió>/ mappába menti"""
    url = BASE_URL + file_path
    version_dir = DOCS_BASE_DIR / f"v{version}"
    version_dir.mkdir(parents=True, exist_ok=True)
    local_path = version_dir / os.path.basename(file_path)
    try:
        r = requests.get(url)
        r.raise_for_status()
        with open(local_path, "wb") as f:
            f.write(r.content)
        print(f"[INFO] {file_path} letöltve → {local_path}")
        return True
    except Exception as e:
        print(f"[ERROR] Hiba a {file_path} letöltésekor:", e)
        return False

def update_docs():
    """Frissíti a dokumentáció PDF-et a legújabb verzióhoz és törli a régi verziókat"""
    version_data = fetch_version()
    if not version_data:
        return

    version = version_data.get("version", "0.0")
    docs_files = version_data.get("docs", [])
    print(f"[INFO] Legújabb verzió: {version}")

    # Régi verziók törlése
    clear_old_versions(version)

    # PDF letöltés
    for doc in docs_files:
        if doc.lower().endswith(".pdf"):
            download_pdf(doc, version)

if __name__ == "__main__":
    update_docs()

