import tkinter as tk
from tkinter import messagebox
import requests
import webbrowser

# Repo beállítások
GITHUB_API = "https://api.github.com/repos/PetiRu/Updater_via_piac_figyelo/contents/tradingview/pine_script"
RAW_URL = "https://raw.githubusercontent.com/PetiRu/Updater_via_piac_figyelo/main/tradingview/pine_script/"

class IndicatorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Indikátor Letöltő & Megnyitó")
        self.root.geometry("400x300")

        self.label = tk.Label(root, text="Elérhető indikátorok a GitHub-ról:")
        self.label.pack(pady=5)

        self.listbox = tk.Listbox(root, width=50, height=10)
        self.listbox.pack(pady=5)

        self.btn_refresh = tk.Button(root, text="Frissítés", command=self.fetch_indicators)
        self.btn_refresh.pack(pady=5)

        self.btn_open = tk.Button(root, text="Megnyitás TradingView-ban", command=self.open_indicator)
        self.btn_open.pack(pady=5)

        # Indításkor frissítjük a listát
        self.fetch_indicators()

    def fetch_indicators(self):
        """Letölti az indikátorok listáját a GitHub API-ból"""
        try:
            resp = requests.get(GITHUB_API, timeout=10)
            resp.raise_for_status()
            files = resp.json()

            self.listbox.delete(0, tk.END)
            for f in files:
                if f["name"].endswith(".pine") or f["name"].endswith(".txt"):
                    self.listbox.insert(tk.END, f["name"])
        except Exception as e:
            messagebox.showerror("Hiba", f"Nem sikerült lekérni a fájlokat!\n{e}")

    def open_indicator(self):
        """Megnyitja a kiválasztott indikátort a TradingView Pine Editorban"""
        selection = self.listbox.curselection()
        if not selection:
            messagebox.showwarning("Figyelmeztetés", "Válassz ki egy indikátort!")
            return

        filename = self.listbox.get(selection[0])
        url = RAW_URL + filename

        try:
            # Letöltés
            resp = requests.get(url, timeout=10)
            resp.raise_for_status()
            code = resp.text

            # Kód megnyitása a TradingView Pine Editorban
            # Használjuk a "https://www.tradingview.com/pine-script-editor/" URL-t
            # A Pine Editor alapból üres kódot ad, de a code-t a clipboard-ra másolhatjuk
            import pyperclip
            pyperclip.copy(code)
            messagebox.showinfo("Kész", f"A kiválasztott indikátor ({filename}) kódja a vágólapra másolva.\nTradingView Pine Editorban Ctrl+V-vel beillesztheted.")
            webbrowser.open("https://www.tradingview.com/pine-script-editor/")

        except Exception as e:
            messagebox.showerror("Hiba", f"Nem sikerült megnyitni a fájlt!\n{e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = IndicatorApp(root)
    root.mainloop()

