import tkinter as tk
from tkinter import messagebox
import requests
import subprocess
import sys

# GitHub raw JSON link
USERS_URL = "https://raw.githubusercontent.com/PetiRu/Updater_via_piac_figyelo/main/users.json"

def fetch_users():
    """Letölti a users.json fájlt GitHubról"""
    try:
        resp = requests.get(USERS_URL, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        return data.get("users", [])
    except Exception as e:
        messagebox.showerror("Hiba", f"Nem sikerült letölteni a users.json fájlt!\n{e}")
        return []

def login():
    username = entry_user.get().strip()
    password = entry_pass.get().strip()

    users = fetch_users()
    for user in users:
        if user["username"] == username and user["password"] == password:
            messagebox.showinfo("Siker", f"Üdvözöllek, {username}!")
            root.destroy()
            run_main()
            return

    messagebox.showerror("Hiba", "Hibás felhasználónév vagy jelszó!")

def run_main():
    """Elindítja a main.py fájlt"""
    try:
        subprocess.Popen([sys.executable, "main.py"])
    except Exception as e:
        messagebox.showerror("Hiba", f"Nem sikerült elindítani a main.py-t!\n{e}")

# ---- GUI ----
root = tk.Tk()
root.title("Bejelentkezés")
root.geometry("300x180")

lbl_user = tk.Label(root, text="Felhasználónév:")
lbl_user.pack(pady=5)
entry_user = tk.Entry(root)
entry_user.pack(pady=5)

lbl_pass = tk.Label(root, text="Jelszó:")
lbl_pass.pack(pady=5)
entry_pass = tk.Entry(root, show="*")
entry_pass.pack(pady=5)

btn_login = tk.Button(root, text="Bejelentkezés", command=login)
btn_login.pack(pady=10)

root.mainloop()

